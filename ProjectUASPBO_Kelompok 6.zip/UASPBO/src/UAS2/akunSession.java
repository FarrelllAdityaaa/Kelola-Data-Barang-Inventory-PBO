/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UAS2;

/**
 *
 * @author USER
 */
public class akunSession {
    private static String u_username;
     


    public static String getU_username() {
        return u_username;
    }
 
    public static void setU_username(String u_username) {
        akunSession.u_username = u_username;
    }
}
